from .deepfake_detector import DeepfakeDetector
from .npr_detector import NPRDetector
from .ucf_detector import UCFDetector
from .camo_detector import CAMODetector